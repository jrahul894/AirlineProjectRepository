package com.project.springboothotelproject.payloads;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ApiResponse {

    private LocalDateTime timeStamp;
    private String mesg;

    public ApiResponse(String mesg)
    {
        this.mesg=mesg;
        this.timeStamp=LocalDateTime.now();
    }
}
