package com.project.springboothotelproject.service;

import java.util.List;

import com.project.springboothotelproject.payloads.PaymentDto;

public interface PaymentService {
    String addPayment(PaymentDto paymentDto);
    List<PaymentDto> getAllPayments();
}
