package com.project.springboothotelproject.enitites;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "payment")
public class Payment {
    @Id
    private String paymentId;
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_mode",nullable = false)
    private PaymentMode paymentMode;
    @Column(name = "payment_amount",nullable = false)
    private Integer paymentAmount;
    @Column(name = "payment_status",nullable = false)
    private String paymentStatus;
    @OneToOne
    @JoinColumn(name = "guest_id")
    private Guest guest;
}
