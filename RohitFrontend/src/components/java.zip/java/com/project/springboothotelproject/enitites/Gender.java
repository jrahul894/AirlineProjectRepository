package com.project.springboothotelproject.enitites;

public enum Gender {
    MALE,FEMALE
}
