package com.project.springboothotelproject.controller;

import com.project.springboothotelproject.payloads.ApiResponse;
import com.project.springboothotelproject.payloads.HotelDto;
import com.project.springboothotelproject.service.HotelServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/hotel")
@CrossOrigin("http://localhost:3000/")
public class HotelController {
    @Autowired
    private HotelServiceImpl hotelService;


    //Adding a new Hotel -- FUNCTIONALITY OF ADMIN
    @PostMapping
    public ResponseEntity<?> addNewHotel(@RequestBody HotelDto hotelDto)
    {
        String message=hotelService.addHotels(hotelDto);
        return new ResponseEntity<>(new ApiResponse(message), HttpStatus.CREATED);
    }


    //Getting all the list of Hotels
    @GetMapping
    public ResponseEntity<List<HotelDto>> viewRooms()
    {
        List<HotelDto> list=hotelService.getHotels();
        return new ResponseEntity<List<HotelDto>>(list,HttpStatus.OK);
    }


    //Edit a HotelName as per Hotel Id
    @PutMapping("/{hotelId}/hotelName/{hotelName}")
    public ResponseEntity<?> editHotel(@PathVariable Long hotelId,@PathVariable String hotelName)
    {
        String message=hotelService.editHotels(hotelId, hotelName);
        return new ResponseEntity<>(new ApiResponse(message),HttpStatus.OK);
    }
    
    @GetMapping("/{city}/hotelType/{hotelType}")
    public ResponseEntity<List<HotelDto>> getHotelInCity(@PathVariable String city, @PathVariable String hotelType) {
        // You might need to implement logic to filter hotels by name and type
        List<HotelDto> list = hotelService.getHotelsByCityAndType(city, hotelType);
        return new ResponseEntity<>(list, HttpStatus.OK);
    }


    //Delete a hotel
    @DeleteMapping("/{hotelId}")
    public ResponseEntity<?> deleteHotel(@PathVariable Long hotelId)
    {
        String message=hotelService.deleteHotels(hotelId);
        return new ResponseEntity<>(new ApiResponse(message),HttpStatus.OK);
    }

    

    //Editing all Fields of Hotel at same time
    @PutMapping("/{hotelId}")
    public ResponseEntity<?> editHotelFields(@PathVariable Long hotelId,@RequestBody HotelDto hotelDto)
    {
        String message=hotelService.editAllFields(hotelId,hotelDto);
        return new ResponseEntity<>(new ApiResponse(message),HttpStatus.OK);

    }

}
