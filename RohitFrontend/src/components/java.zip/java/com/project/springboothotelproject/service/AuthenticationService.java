package com.project.springboothotelproject.service;

import com.project.springboothotelproject.models.AuthenticateRequest;
import com.project.springboothotelproject.models.AuthenticateResponse;
import com.project.springboothotelproject.repository.GuestRepository;
import com.project.springboothotelproject.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

    private final GuestRepository guestRepo;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    public AuthenticateResponse authenticate(AuthenticateRequest request) {
        System.out.println("Inside auth service");
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUserName(),
                        request.getPassword()
                )
        );
        var user=guestRepo.findByEmail(request.getUserName())
                .orElseThrow();
        System.out.println("User :"+user);
        var jwtToken=jwtService.generateToken(user);
        System.out.println("Jwt Token :"+jwtToken);
        return AuthenticateResponse.builder()
                .token(jwtToken)
                .build();
    }
}
