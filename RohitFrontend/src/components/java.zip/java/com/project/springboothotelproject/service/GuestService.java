package com.project.springboothotelproject.service;

import java.util.List;

import com.project.springboothotelproject.payloads.GuestDto;


public interface GuestService {
    String addGuest(GuestDto guestDto);
    List<GuestDto> getAllGuests();
}
