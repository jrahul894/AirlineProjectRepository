package com.project.springboothotelproject.payloads;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.Future;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BookingDto {

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long hotelId;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long roomId;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long guestId;

    @Future(message = "Check in date can't be date in past")
    private LocalDate bookingDate;
    @Future(message = "Check out date can't be date in past")
    private LocalDate checkOutDate;
    /*@Positive
    @Min(value = 1000,message = "Booking Amount can't be less than Rs.1000")
    private Double BookingAmount;*/
}
