package com.project.springboothotelproject.service;

import java.util.List;

import com.project.springboothotelproject.payloads.RoomDto;


public interface RoomService {
    String addRoom(RoomDto roomDto);
    List<RoomDto> getAllRooms();
    List<RoomDto> getAllRoomsByHotelName(String hotelName);
    String editRoom(Long roomId,String roomType);
    String deleteRooms(Long roomId);
}
