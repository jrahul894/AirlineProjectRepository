package com.project.springboothotelproject.payloads;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.springboothotelproject.enitites.Address;
import com.project.springboothotelproject.enitites.Gender;
import lombok.*;

import javax.validation.constraints.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class GuestDto {
    @NonNull
    @NotBlank(message = "Name can't be blank")
    private String firstName;
    @NonNull
    @NotBlank(message = "Name can't be blank")
    private String lastName;
    @NonNull
    @NotBlank(message = "Name can't be blank")
    private Gender gender;
    @Positive
    @Min(value = 18,message = "Age can't be less than 18 years")
    @Max(value = 100,message = "Invalid age")
    private Integer age;
    @NonNull
    @NotBlank(message = "Address can't be blank")
    private Address address;
    @NonNull
    @Positive
    @Size(min = 10,max = 12,message = "Contact Number should be in range")
    private Long contactNo;
    @Email
    private String email;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @NonNull
    @NotBlank(message = "Password can't be empty")
    @Size(min = 3,max=25)
    private String password;
}
