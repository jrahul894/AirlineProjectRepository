package com.project.springboothotelproject.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.springboothotelproject.enitites.Hotel;
import com.project.springboothotelproject.enitites.HotelType;

@Repository
public interface HotelRepository extends JpaRepository<Hotel,Long> {
	
	//Optional<List<Hotel>> findByHotelNameAndHotelType(String hotelName,String hotelType);
	Optional<List<Hotel>> findByAddressCityAndHotelType(String city,HotelType hotelType);
}
