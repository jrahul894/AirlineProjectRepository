package com.project.springboothotelproject.payloads;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.springboothotelproject.enitites.RoomType;
import lombok.*;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RoomDto {
    @NonNull
    @NotBlank(message = "Room Type can't be blank")
    private RoomType roomType;
    @NotBlank(message = "Room Description can't be blank")
    private String aboutRoom;
    @NotBlank(message = "Room Facilities can't be blank")
    private String roomFacilities;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long hotelId;
    /*@Positive
    @Min(value = 1,message = "At least 1 ")
    private Integer noOfRooms;*/
}
