package com.project.springboothotelproject.payloads;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.springboothotelproject.enitites.PaymentMode;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PaymentDto {

    @NonNull
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long guestId;
    @NonNull
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long roomId;
    @NonNull
    @NotBlank(message = "Payment mode can't be blank")
    private PaymentMode paymentMode;
    @Positive
    private Integer paymentAmount;

}
