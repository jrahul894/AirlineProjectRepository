package com.project.springboothotelproject.repository;

import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.project.springboothotelproject.enitites.Room;

@Repository
public interface RoomRepository extends JpaRepository<Room,Long> {
    @Query("SELECT SUM(roomCount) FROM Room WHERE hotel.hotelId=:hotelId")
    Long findSumofRoomsByHotelId(@Param("hotelId") Long hotelId);

    Optional< List <Room> > findAllByHotelHotelName(String hotelName);
}
