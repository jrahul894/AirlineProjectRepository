package com.project.springboothotelproject.service;

import java.util.List;

import com.project.springboothotelproject.payloads.HotelDto;

public interface HotelService {
    String addHotels(HotelDto hotel);
    List<HotelDto> getHotels();
    String editHotels(Long hotelId,String hotelName);
    String deleteHotels(Long hotelId);
    String editAllFields(Long hotelId,HotelDto hotelDto);
	List<HotelDto> getHotelsByCityAndType(String hotelName, String hotelType);
}
