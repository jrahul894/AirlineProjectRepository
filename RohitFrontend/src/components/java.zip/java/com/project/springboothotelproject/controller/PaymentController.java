package com.project.springboothotelproject.controller;

import com.project.springboothotelproject.payloads.ApiResponse;
import com.project.springboothotelproject.payloads.PaymentDto;
import com.project.springboothotelproject.service.PaymentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    private PaymentService paymentService;

    @PostMapping
    public ResponseEntity<?> addNewPayment(@RequestBody PaymentDto paymentDto)
    {
        String message=paymentService.addPayment(paymentDto);
        return new ResponseEntity<>(new ApiResponse(message), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<PaymentDto>> viewAllPayments()
    {
        List<PaymentDto> list=paymentService.getAllPayments();
        return  new ResponseEntity<List<PaymentDto>>(list,HttpStatus.OK);
    }
}
