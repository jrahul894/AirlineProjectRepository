package com.project.springboothotelproject.enitites;

import jakarta.persistence.Embeddable;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Embeddable
public class Address {
    private String streetAddress;
    private String city;
    private String state;
    private Integer zipCode;
}
