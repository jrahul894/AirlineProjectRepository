package com.project.springboothotelproject.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.springboothotelproject.enitites.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking,String> {
    Optional<Booking> findByGuestGuestId(Long guestId);
}
