package com.project.springboothotelproject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.springboothotelproject.enitites.Guest;
import com.project.springboothotelproject.enitites.Payment;
import com.project.springboothotelproject.enitites.Room;
import com.project.springboothotelproject.exceptionhandler.ResourceNotFoundException;
import com.project.springboothotelproject.payloads.PaymentDto;
import com.project.springboothotelproject.repository.BookingRepository;
import com.project.springboothotelproject.repository.GuestRepository;
import com.project.springboothotelproject.repository.PaymentRepository;
import com.project.springboothotelproject.repository.RoomRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentService{

    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private ModelMapper maper;
    @Autowired
    private GuestRepository guestRepository;
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Override
    public String addPayment(PaymentDto paymentDto)
    {
        Guest guest=guestRepository.findById(paymentDto.getGuestId()).orElseThrow(()-> new ResourceNotFoundException("Invalid Guest Id"));
        Room room=roomRepository.findById(paymentDto.getRoomId()).orElseThrow(()-> new ResourceNotFoundException("Invalid Room Id"));
        if(paymentDto.getPaymentAmount().equals(room.getRoomPrice()))
        {
            Payment payment=maper.map(paymentDto, Payment.class);
            payment.setPaymentId(UUID.randomUUID().toString());
            payment.setPaymentStatus("CLEARED");
            payment.setGuest(guest);
            paymentRepository.save(payment);

            return ("Payment added successfully");
        }
        else return ("Amount not matched");
    }

    @Override
    public List<PaymentDto> getAllPayments()
    {
        List<Payment> payments=paymentRepository.findAll();
        List<PaymentDto> lists=new ArrayList<>();

        for(Payment p:payments)
        {
            lists.add(maper.map(p, PaymentDto.class));
        }
        return lists;
    }
}
