package com.project.springboothotelproject.service;

import com.project.springboothotelproject.enitites.*;
import com.project.springboothotelproject.exceptionhandler.ResourceNotFoundException;
import com.project.springboothotelproject.payloads.BookingDto;
import com.project.springboothotelproject.repository.*;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class BookingServiceImpl implements BookingService{

    @Autowired
    private BookingRepository bookRepo;
    @Autowired
    private GuestRepository guestRepo;
    @Autowired
    private ModelMapper maper;
    @Autowired
    private HotelRepository hotelRepository;
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private PaymentRepository paymentRepository;
    @Override
    public String addNewBooking(BookingDto bookingDto) {
        Hotel hotel= hotelRepository.findById(bookingDto.getHotelId()).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel Id"));
        Room room= roomRepository.findById(bookingDto.getRoomId()).orElseThrow(()-> new ResourceNotFoundException("Invalid Room Id"));
        Guest guest=guestRepo.findById(bookingDto.getGuestId()).orElseThrow(()-> new ResourceNotFoundException("Wrong Customer Name.. Register first!!"));
        Payment payment=paymentRepository.findByGuestGuestId(bookingDto.getGuestId()).orElseThrow(()-> new ResourceNotFoundException("Pay the required amount first"));

        if(payment.getPaymentStatus().equals("CLEARED")) {
            Booking booking = maper.map(bookingDto, Booking.class);
            booking.setBookingId(UUID.randomUUID().toString());
            booking.setBookingDate(LocalDateTime.now());
            booking.setGuest(guest);
            booking.setRoom(room);
            booking.setHotel(hotel);
            bookRepo.save(booking);

            return ("Booking with Id " + booking.getBookingId() + " added successfully");
        }
        else return ("First process the payment");
    }

    @Override
    public List<BookingDto> getAllBookings() {
        List<Booking> bookings=bookRepo.findAll();
        List<BookingDto> lists=new ArrayList<>();

        for(Booking b:bookings)
        {
            lists.add(maper.map(b, BookingDto.class));
        }

        return lists;
    }
}
