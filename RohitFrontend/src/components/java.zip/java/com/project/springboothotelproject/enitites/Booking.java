package com.project.springboothotelproject.enitites;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "booking")
public class Booking {
    @Id
    private String bookingId;
    @Column(name="booking_date")
    private LocalDateTime bookingDate;
    @Column(name = "check_in_date")
     private LocalDate checkOutDate;
    @Column(name="booking_amount")
    private Double BookingAmount;
    /*@Column(name = "hotel_id")
    private Long hotelId;*/
    @ManyToOne
    @JoinColumn(name = "guest_id")
    private Guest guest;
    @ManyToOne
    @JoinColumn(name = "room_id")
    private Room room;
    @ManyToOne
    @JoinColumn(name = "hotel_id")
    private Hotel hotel;
}
