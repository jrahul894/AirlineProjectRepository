package com.project.springboothotelproject.controller;

import com.project.springboothotelproject.payloads.ApiResponse;
import com.project.springboothotelproject.payloads.RoomDto;
import com.project.springboothotelproject.service.RoomService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/room")
public class RoomController {

    @Autowired
    private RoomService roomService;


    //Adding a new Room in a Hotel
    @PostMapping
    public ResponseEntity<?> addNewRoom(@RequestBody RoomDto roomDto)
    {
        String message=roomService.addRoom(roomDto);
        return new ResponseEntity<>(new ApiResponse(message), HttpStatus.CREATED);
    }


    //Getting the details of all the rooms
    @GetMapping
    public ResponseEntity<List<RoomDto>> viewRooms()
    {
        List<RoomDto> list=roomService.getAllRooms();
        return new ResponseEntity<List<RoomDto>>(list,HttpStatus.OK);
    }


    //Getting the Details Of room as per hotel name
    @GetMapping("/hotels/{hotelName}")
    public ResponseEntity<List<RoomDto>> viewRoomsByHotelName(@PathVariable String hotelName)
    {
        List<RoomDto> roomsList=roomService.getAllRoomsByHotelName(hotelName);
        return new ResponseEntity<List<RoomDto>>(roomsList,HttpStatus.FOUND);
    }


    //Editing a Room as per room Id
    @PutMapping("/{roomId}/roomType/{roomType}")
    public ResponseEntity<?> editRoom(@PathVariable Long roomId,@PathVariable String roomType)
    {
        String message=roomService.editRoom(roomId, roomType);
        return new ResponseEntity<>(new ApiResponse(message),HttpStatus.OK);
    }


    //Deleting a room as per room Id
    @DeleteMapping("/{roomId}")
    public ResponseEntity<?> deleteHotel(@PathVariable Long roomId)
    {
        String message=roomService.deleteRooms(roomId);
        return new ResponseEntity<>(new ApiResponse(message),HttpStatus.OK);
    }
}
