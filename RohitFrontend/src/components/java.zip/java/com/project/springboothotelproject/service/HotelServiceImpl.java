package com.project.springboothotelproject.service;

import com.project.springboothotelproject.enitites.Hotel;
import com.project.springboothotelproject.enitites.HotelType;
import com.project.springboothotelproject.exceptionhandler.ResourceNotFoundException;
import com.project.springboothotelproject.payloads.HotelDto;
import com.project.springboothotelproject.repository.HotelRepository;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class HotelServiceImpl implements HotelService{
    @Autowired
    private HotelRepository hotelRepo;

    @Autowired
    private ModelMapper maper;

    //Adding a new Hotel
    @Override
    public String addHotels(HotelDto hotel) {
        String msg="Added successfully";
        Hotel h=maper.map(hotel, Hotel.class);
        hotelRepo.save(h);
        return ("Hotel "+h.getHotelName()+" "+msg);
    }


    //Getting all the details of Hotels
    @Override
    public List<HotelDto> getHotels() {
        List<Hotel> hotelList=hotelRepo.findAll();
        List<HotelDto> hotelDtoList=new ArrayList<>();
        for(Hotel h:hotelList)
        {
            hotelDtoList.add(maper.map(h, HotelDto.class));
        }
        return hotelDtoList;
    }


    //Edit HotelName as per Hotel Id
    @Override
    public String editHotels(Long hotelId,String hotelName)
    {
        String msg="Updated Successfully";
        Hotel hotel=hotelRepo.findById(hotelId).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel Id!!"));

        hotel.setHotelName(hotelName);
        hotelRepo.save(hotel);

        return ("Hotel having "+hotel.getHotelId()+" "+msg);
    }


    //Delete Hotel as per hotel Id
    @Override
    public String deleteHotels(Long hotelId)
    {
        String msg="Deleted Successfully";
        Hotel hotel=hotelRepo.findById(hotelId).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel Id!!"));

        hotelRepo.delete(hotel);
        return ("Hotel "+hotel.getHotelName()+" "+msg);
    }


    //Edit all the hotel fields as per hotel Id
    @Override
    public String editAllFields(Long hotelId,HotelDto hotelDto)
    {
        String msg="Updated Successfully";
        Hotel hotel=hotelRepo.findById(hotelId).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel Id!!"));

        Hotel updatedDetails=maper.map(hotelDto, Hotel.class);
        hotel.setHotelName(updatedDetails.getHotelName());
        hotel.setContactNo(updatedDetails.getContactNo());
        hotel.setHotelAmenities(updatedDetails.getHotelAmenities());
        hotel.setAboutHotel(updatedDetails.getAboutHotel());
        hotel.setHotelType(updatedDetails.getHotelType());
        hotel.setAddress(updatedDetails.getAddress());

        hotelRepo.save(hotel);
        return ("Hotel havind id "+hotel.getHotelId()+" "+msg);

    }


    @Override
	public List<HotelDto> getHotelsByCityAndType(String city, String hotelType) {
    	List<Hotel> hotelList=hotelRepo.findByAddressCityAndHotelType (city,HotelType.valueOf(hotelType)).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel City !!"));
        List<HotelDto> hotelDtoList=new ArrayList<>();
        for(Hotel h:hotelList)
        {
            hotelDtoList.add(maper.map(h, HotelDto.class));
        }
        return hotelDtoList;
    	
	
	}
}
