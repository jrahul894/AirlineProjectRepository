package com.project.springboothotelproject.enitites;

public enum HotelType {
    TWOSTAR,THREESTAR,FOURSTAR,FIVESTAR
}
