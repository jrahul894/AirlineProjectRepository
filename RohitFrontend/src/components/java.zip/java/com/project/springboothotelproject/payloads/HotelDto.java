package com.project.springboothotelproject.payloads;

import com.project.springboothotelproject.enitites.Address;
import com.project.springboothotelproject.enitites.HotelType;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class HotelDto {
        @NotBlank(message = "Hotel name can't be blank")
        @Size(min=3,message = "Hotel name should be atleast 3 characters long")
        private String hotelName;

        @NotBlank(message = "Description can't be blank")
        @Size(min=25,message="Hotel description should be atleast 25 characters long")
        private String aboutHotel;

        @NotBlank(message = "Hotel location can't be blank")
        @Size(min=3,message = "Hotel location should be atleast 3 characters long")
        private Address address;

        @Positive(message = "Contact Number can't be negative")
        @NotNull(message = "Contact number should be there")
        @Size(min=10,max=12,message="Contact Number should be in range")
        private Long contactNo;

        @NonNull
        private HotelType hotelType;

        @NonNull
        @NotBlank(message = "Hotel Amenities can't be blank")
        private String hotelAmenities;

        @Positive(message = "Room capacity can't be a negative value")
        private Integer roomCapacity;

}
