package com.project.springboothotelproject.service;

import com.project.springboothotelproject.enitites.Guest;
import com.project.springboothotelproject.payloads.GuestDto;
import com.project.springboothotelproject.repository.GuestRepository;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class GuestServiceImpl implements GuestService {
    @Autowired
    private GuestRepository guestRepo;
    @Autowired
    private ModelMapper maper;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Override
    public String addGuest(GuestDto guestDto) {
       Guest guest=maper.map(guestDto, Guest.class);
       guest.setPassword(passwordEncoder.encode(guestDto.getPassword()));
       guestRepo.save(guest);
       return  ("Guest id "+guest.getGuestId()+" Added successfully");
    }

    @Override
    public List<GuestDto> getAllGuests() {
        List<Guest> list=guestRepo.findAll();
        List<GuestDto> guestLists=new ArrayList<>();
        for(Guest g:list)
        {
            guestLists.add(maper.map(g,GuestDto.class));
        }

        return guestLists;
    }

    /*@Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return guestRepo.findByEmail(username).orElseThrow(()-> new ResourceNotFoundException("Invalid UserName"));
    }*/
}
