package com.project.springboothotelproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.springboothotelproject.models.AuthenticateRequest;
import com.project.springboothotelproject.models.AuthenticateResponse;
import com.project.springboothotelproject.payloads.ApiResponse;
import com.project.springboothotelproject.payloads.BookingDto;
import com.project.springboothotelproject.service.AuthenticationService;
import com.project.springboothotelproject.service.BookingService;
import java.util.*;


@RestController
@RequestMapping("/booking")
public class BookingController {
    @Autowired
    BookingService bookingService;
    @Autowired
    AuthenticationService authenticationService;
    @PostMapping("/authenticate")
    public ResponseEntity<AuthenticateResponse> register(@RequestBody AuthenticateRequest request)
    {
        return ResponseEntity.ok(authenticationService.authenticate(request));
    }

    @PostMapping("/add-booking")
    public ResponseEntity<?> addBooking(@RequestBody BookingDto bookingDto)
    {
        String message=bookingService.addNewBooking(bookingDto);
        return new ResponseEntity<>(new ApiResponse(message), HttpStatus.CREATED);
    }

    @GetMapping("/get-booking")
    public ResponseEntity<List<BookingDto>> viewBookingDetails()
    {
        List<BookingDto> list=bookingService.getAllBookings();
        return new ResponseEntity<List<BookingDto>>(list,HttpStatus.OK);
    }
}
