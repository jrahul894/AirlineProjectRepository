package com.project.springboothotelproject.enitites;

public enum RoomType {
    DELUXE(5000),SUITE(10000),DOUBLE_ROOM(2000);
    int price;

    RoomType(int price)
    {
        this.price=price;
    }

    public int getPrice() {
        return price;
    }
}
