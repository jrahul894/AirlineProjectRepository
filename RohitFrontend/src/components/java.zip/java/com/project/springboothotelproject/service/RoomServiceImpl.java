package com.project.springboothotelproject.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.springboothotelproject.enitites.Hotel;
import com.project.springboothotelproject.enitites.Room;
import com.project.springboothotelproject.enitites.RoomType;
import com.project.springboothotelproject.exceptionhandler.ResourceNotFoundException;
import com.project.springboothotelproject.payloads.RoomDto;
import com.project.springboothotelproject.repository.HotelRepository;
import com.project.springboothotelproject.repository.RoomRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class RoomServiceImpl implements RoomService{
    @Autowired
    private RoomRepository roomRepository;
    @Autowired
    private ModelMapper maper;
    @Autowired
    private HotelRepository hotelRepository;
    @Override
    public String addRoom(RoomDto roomDto) {
       Hotel hotel= hotelRepository.findById(roomDto.getHotelId()).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel Id"));
       Long currentCapacity=roomRepository.findSumofRoomsByHotelId(roomDto.getHotelId());
       if(hotel.getRoomCapacity()<currentCapacity) {
           Room room = maper.map(roomDto, Room.class);
           room.setRoomPrice(roomDto.getRoomType().getPrice());
           room.setHotel(hotel);
           room.setRoomCount(room.getRoomCount()+1);
           roomRepository.save(room);
           return ("Room having room id " + room.getRoomId() + " added successfully");
       }
       return ("Room can't be added as Hotel Room Accommodations are full");
    }

    @Override
    public List<RoomDto> getAllRooms() {
        List<Room> roomsList=roomRepository.findAll();
        List<RoomDto> roomDtoList=new ArrayList<>();
        for(Room r:roomsList)
        {
            roomDtoList.add(maper.map(r, RoomDto.class));
        }
        return roomDtoList;
    }

    @Override
    public List<RoomDto> getAllRoomsByHotelName(String hotelName)
    {
        List<Room> list=roomRepository.findAllByHotelHotelName(hotelName).orElseThrow(()-> new ResourceNotFoundException("Invalid Hotel Name"));
        List<RoomDto> lists=new ArrayList<>();
        for(Room r:list)
        {
            lists.add(maper.map(r, RoomDto.class));
        }
        return lists;
    }
    @Override
    public String editRoom(Long roomId,String roomType)
    {
        String msg="Updated Successfully";
        Room room=roomRepository.findById(roomId).orElseThrow(()-> new ResourceNotFoundException("Invalid Room Id!!"));

        room.setRoomType(RoomType.valueOf(roomType));
        roomRepository.save(room);

        return ("Room having id "+room.getRoomId()+" updated successfully");
    }

    //Delete rooms as per room Id
    @Override
    public String deleteRooms(Long roomId)
    {
        String msg="Deleted Successfully";
        Room room=roomRepository.findById(roomId).orElseThrow(()-> new ResourceNotFoundException("Invalid Room Id!!"));

        roomRepository.delete(room);
        return ("Room having id "+room.getRoomId()+" "+msg);
    }

}
