package com.project.springboothotelproject.service;

import java.util.List;

import com.project.springboothotelproject.payloads.BookingDto;


public interface BookingService {


    String addNewBooking(BookingDto bookingDto);
    List<BookingDto> getAllBookings();
}
